// Global variables
let currentPage = 1;
let countdownInterval;
let processingInterval;

// Page navigation function
function goToPage(pageNumber) {
    // Hide current page
    document.querySelector(`.page-${currentPage}`).classList.remove('active');
    
    // Show new page
    currentPage = pageNumber;
    const newPage = document.querySelector(`.page-${pageNumber}`);
    newPage.classList.add('active');
    
    // Handle specific page logic
    if (pageNumber === 3) {
        startProcessingSequence();
    } else if (pageNumber === 4) {
        startCountdown();
    } else if (pageNumber === 5) {
        startFinalVerification();
    }
}

// Handle form submission
function handleFormSubmit(event) {
    event.preventDefault();
    goToPage(3);
}

// Processing animation for page 3
function startProcessingSequence() {
    const statusTexts = [
        'Processing your information',
        'Verifying account details',
        'Setting up your NOVA CASH account',
        'Almost done'
    ];
    
    let currentIndex = 0;
    const statusElement = document.getElementById('statusText');
    
    processingInterval = setInterval(() => {
        if (currentIndex < statusTexts.length) {
            statusElement.textContent = statusTexts[currentIndex];
            currentIndex++;
        } else {
            clearInterval(processingInterval);
            setTimeout(() => goToPage(4), 1000);
        }
    }, 900);
}

// Final verification animation for page 5
function startFinalVerification() {
    const statusTexts = [
        'Verifying your payment',
        'Verifying account details',
        'Processing',
        'Almost done'
    ];
    
    let currentIndex = 0;
    const statusElement = document.getElementById('finalStatusText');
    
    processingInterval = setInterval(() => {
        if (currentIndex < statusTexts.length) {
            statusElement.textContent = statusTexts[currentIndex];
            currentIndex++;
        } else {
            clearInterval(processingInterval);
            setTimeout(() => goToPage(6), 1000);
        }
    }, 900);
}

// Countdown timer for page 4
function startCountdown() {
    let timeLeft = 7 * 60; // 7 minutes in seconds
    const timerElement = document.getElementById('countdown');
    
    countdownInterval = setInterval(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        
        timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        if (timeLeft <= 0) {
            clearInterval(countdownInterval);
            goToPage(6);
        }
        
        timeLeft--;
    }, 1000);
}

// Handle file upload
function handleUpload() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
        const file = e.target.files[0];
        if (file) {
            // Silent upload - no notification
            console.log('Receipt uploaded:', file.name);
        }
    };
    input.click();
}

// Copy to clipboard function
function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(() => {
        // Visual feedback
        button.classList.add('copied');
        button.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>';
        
        setTimeout(() => {
            button.classList.remove('copied');
            button.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy text: ', err);
    });
}

// Cleanup intervals when page changes
window.addEventListener('beforeunload', () => {
    clearInterval(countdownInterval);
    clearInterval(processingInterval);
});